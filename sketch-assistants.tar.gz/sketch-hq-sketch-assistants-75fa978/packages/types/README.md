# sketch-assistant-types

TypeScript types for Sketch Assistants.

> 🙋‍♀️ The types exported from this module are generally useful to any TypeScript project related to
> Assistants, including the development of individual Assistant packages themselves.

## Usage

```sh
yarn add @sketch-hq/sketch-assistant-types
```
