module.exports = {
  sourceLocale: 'en',
  srcPathDirs: ['<rootDir>/src'],
  format: 'po',
  sorting: 'origin',
  localeDir: '<rootDir>/src/locale',
}
