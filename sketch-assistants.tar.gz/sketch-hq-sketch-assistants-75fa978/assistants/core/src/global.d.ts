declare module '*locale/en/messages'

declare module '*locale/zh-Hans/messages'
