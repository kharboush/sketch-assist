# groups-no-empty

Empty groups are considered a violations.

## Rationale

Empty groups can collect in a document over time due to copy and paste errors, and could be
considered a document hygiene or usability concern by some teams.

## Options

None.
