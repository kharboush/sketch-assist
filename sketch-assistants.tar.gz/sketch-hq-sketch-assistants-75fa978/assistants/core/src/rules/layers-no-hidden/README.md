# layers-no-hidden

Layers that have been visually hidden in the layer list are considered violations.

## Rationale

Hidden layers can introduce uncertainty about their intended purpose so some teams may wish to
forbid them.

## Options

None.
