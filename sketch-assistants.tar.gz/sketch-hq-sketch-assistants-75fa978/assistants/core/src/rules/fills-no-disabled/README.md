# fills-no-disabled

Any layer with a disabled fill style is considered a violation.

## Rationale

Depending on the requirements of the document, disabled properties in the inspector can introduce
uncertainty about their intended purpose so some teams may wish to forbid them.

## Options

None.
