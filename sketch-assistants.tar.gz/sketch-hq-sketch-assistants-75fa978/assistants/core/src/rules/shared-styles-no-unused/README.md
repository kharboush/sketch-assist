# shared-styles-no-unused

Shared styles that aren't applied to any layer are considered violations.

## Rationale

Unused shared styles could be considered a document hygiene issue by some teams.

## Options

None.
