# shadows-no-disabled

Any layer with a disabled shadow style is considered a violations.

## Rationale

Depending on the requirements of the document, disabled properties in the inspector can introduce
uncertainty about their intended purpose so some teams may wish to forbid them.

## Options

None.
