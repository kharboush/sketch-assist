# symbols-no-unused

Symbols that see no usage in the document are considered violations.

## Rationale

Unused symbols could be considered a document hygiene issue by some teams.

## Options

None.
