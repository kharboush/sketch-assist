# layers-no-loose

Layers that exist outside of artboards are considered a violation.

## Rationale

Layers outside of artboards aren't visible on Sketch Cloud, some teams may wish to forbid them.

## Options

None.
