# symbols-no-detached

Groups derived from detaching a symbol are considered violations.

## Rationale

Detached symbols could indicate an unwanted divergence from a style guide or library.

## Options

None.
